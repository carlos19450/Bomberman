using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour
{
    public void EscenaJuego()
    {
        SceneManager.LoadScene("Bomberman");
    }

    public void Salir()
    {
        Application.Quit();
    }
}
